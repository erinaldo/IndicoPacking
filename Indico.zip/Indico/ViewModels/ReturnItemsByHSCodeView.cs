﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndicoPacking.ViewModels
{
    class ReturnItemsByHSCodeView
    {
        public string Material { get; set; }
        public string ItemName { get; set; }
        public string Gender { get; set; }
        public string ItemSubGroup { get; set; }
        public string Qty { get; set; }
        public string TotalPrice { get; set; }
    }
}
